// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyA9q9NF0IFiWHyGMF_O5w_M6dUBiFHYfFE",
    authDomain: "treehacks2020-66c34.firebaseapp.com",
    databaseURL: "https://treehacks2020-66c34.firebaseio.com",
    projectId: "treehacks2020-66c34",
    storageBucket: "treehacks2020-66c34.appspot.com",
    messagingSenderId: "52745561060",
    appId: "1:52745561060:web:7fbd0e67c89f819d029df1",
    measurementId: "G-JG554M9YMC"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
