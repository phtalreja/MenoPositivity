# treehacks20-frontend

MenoPositivity is an app designed to help women monitor and predict their symptoms of menopause.
